# VisaPilot production architecture

## Request flow

Browser
→ Next.js frontend/API
→ Supabase
→ verification engine / OpenAI
→ evidence + score
→ user-facing job result

## Data principle

A job record is separate from:
- employer licence status
- sponsorship evidence
- sponsorship score
- candidate feedback

This prevents the platform from making the common mistake of turning "licensed sponsor" into "sponsoring this job".

## Verification lifecycle

1. Job discovered
2. Source captured
3. Job normalised
4. Evidence extracted
5. Evidence stored with source and timestamp
6. Score calculated
7. Conflicts checked
8. Human review when required
9. Published
10. Re-verified or expired

## Security

- Service role key is server-only.
- Browser uses Supabase anon key.
- Row-level security protects user records.
- Sensitive applicant documents should use private storage buckets.
- API input is validated with Zod.
- Production deployment should add rate limiting, bot protection, audit logs and structured error monitoring.

## Production caveat

This package is a production-oriented backend foundation, not a deployed production service. It needs Supabase credentials, an OpenAI API key, environment configuration, domain configuration, testing and deployment before real users are onboarded.
