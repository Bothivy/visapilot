create extension if not exists pgcrypto;

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  target_occupation text,
  years_experience numeric,
  location text,
  visa_requirement text,
  skills jsonb default '[]'::jsonb,
  cv_url text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table public.employers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  website text,
  industry text,
  trust_score numeric check (trust_score between 0 and 100),
  sponsorship_profile jsonb default '{}'::jsonb,
  last_verified_at timestamptz,
  created_at timestamptz default now()
);

create table public.jobs (
  id uuid primary key default gen_random_uuid(),
  employer_id uuid not null references public.employers(id) on delete cascade,
  title text not null,
  occupation text,
  location text,
  salary_min numeric,
  salary_max numeric,
  employment_type text,
  description text not null,
  source_url text not null,
  status text not null default 'active',
  first_seen_at timestamptz default now(),
  last_seen_at timestamptz default now(),
  last_verified_at timestamptz
);

create table public.sponsorship_evidence (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.jobs(id) on delete cascade,
  employer_id uuid references public.employers(id) on delete cascade,
  evidence_type text not null,
  evidence_text text not null,
  source_url text,
  source_date timestamptz,
  reliability_weight numeric not null default 0.5 check (reliability_weight between 0 and 1),
  verified_by text,
  created_at timestamptz default now()
);

create table public.sponsorship_scores (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.jobs(id) on delete cascade,
  score numeric not null check (score between 0 and 100),
  confidence_level text not null,
  score_breakdown jsonb not null,
  explanation text not null,
  calculated_at timestamptz default now()
);

create table public.user_feedback (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  job_id uuid not null references public.jobs(id) on delete cascade,
  outcome text,
  sponsorship_response text,
  notes text,
  created_at timestamptz default now()
);

create table public.applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  job_id uuid not null references public.jobs(id) on delete cascade,
  status text not null default 'saved',
  applied_at timestamptz,
  notes text,
  created_at timestamptz default now()
);

create index jobs_status_score_idx on public.jobs(status, last_verified_at desc);
create index jobs_employer_idx on public.jobs(employer_id);
create index evidence_job_idx on public.sponsorship_evidence(job_id);
create index scores_job_idx on public.sponsorship_scores(job_id, calculated_at desc);

create or replace view public.job_search as
select
  j.id,
  j.title,
  j.occupation,
  j.location,
  j.salary_min,
  j.salary_max,
  j.employment_type,
  j.description,
  j.source_url,
  j.status,
  j.last_verified_at,
  e.id as employer_id,
  e.name as employer_name,
  e.trust_score,
  s.score as sponsorship_score,
  s.confidence_level,
  s.explanation as sponsorship_explanation,
  s.calculated_at as score_calculated_at
from public.jobs j
join public.employers e on e.id = j.employer_id
left join lateral (
  select *
  from public.sponsorship_scores ss
  where ss.job_id = j.id
  order by ss.calculated_at desc
  limit 1
) s on true;

alter table public.profiles enable row level security;
alter table public.employers enable row level security;
alter table public.jobs enable row level security;
alter table public.sponsorship_evidence enable row level security;
alter table public.sponsorship_scores enable row level security;
alter table public.user_feedback enable row level security;
alter table public.applications enable row level security;

create policy "profiles own read" on public.profiles for select using (auth.uid() = id);
create policy "profiles own update" on public.profiles for update using (auth.uid() = id);

create policy "active jobs public read" on public.jobs for select using (status = 'active');
create policy "employers public read" on public.employers for select using (true);
create policy "scores public read" on public.sponsorship_scores for select using (true);
create policy "evidence public read" on public.sponsorship_evidence for select using (true);

create policy "feedback own read" on public.user_feedback for select using (auth.uid() = user_id);
create policy "feedback own insert" on public.user_feedback for insert with check (auth.uid() = user_id);

create policy "applications own read" on public.applications for select using (auth.uid() = user_id);
create policy "applications own insert" on public.applications for insert with check (auth.uid() = user_id);
create policy "applications own update" on public.applications for update using (auth.uid() = user_id);
