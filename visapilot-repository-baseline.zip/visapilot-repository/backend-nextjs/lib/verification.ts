export type Evidence = {
  type: string;
  text: string;
  reliability_weight: number;
  source_url?: string;
  source_date?: string;
};

export type VerificationResult = {
  score: number;
  confidence_level: "Very High" | "High" | "Medium" | "Low" | "Unknown";
  explanation: string;
  breakdown: Record<string, number>;
  contradictions: string[];
};

const weights: Record<string, number> = {
  explicit_vacancy_sponsorship: 35,
  employer_confirmation: 25,
  recent_same_occupation: 15,
  candidate_outcomes: 10,
  salary_occupation_checks: 10,
  freshness: 5
};

export function calculateSponsorshipScore(
  evidence: Evidence[],
  contradictions: string[] = []
): VerificationResult {
  let score = 0;
  const breakdown: Record<string, number> = {};

  for (const [type, max] of Object.entries(weights)) {
    const matching = evidence.filter(e => e.type === type);
    const contribution = matching.length
      ? Math.min(max, Math.max(...matching.map(e => max * Math.min(1, e.reliability_weight))))
      : 0;
    breakdown[type] = Math.round(contribution);
    score += contribution;
  }

  // A sponsor licence alone contributes zero.
  if (evidence.some(e => e.type === "sponsor_licence_only")) {
    score = Math.min(score, 25);
  }

  score -= Math.min(30, contradictions.length * 10);
  score = Math.max(0, Math.min(100, Math.round(score)));

  const confidence_level =
    score >= 85 ? "Very High" :
    score >= 70 ? "High" :
    score >= 50 ? "Medium" :
    score >= 25 ? "Low" : "Unknown";

  return {
    score,
    confidence_level,
    explanation:
      "This score reflects evidence about sponsorship of the vacancy or comparable roles. A sponsor licence by itself is not treated as proof that this vacancy will be sponsored.",
    breakdown,
    contradictions
  };
}