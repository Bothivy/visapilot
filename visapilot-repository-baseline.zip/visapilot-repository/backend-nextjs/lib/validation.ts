import { z } from "zod";

export const jobCreateSchema = z.object({
  employer_id: z.string().uuid(),
  title: z.string().min(2).max(200),
  occupation: z.string().max(200).optional(),
  location: z.string().max(200).optional(),
  salary_min: z.number().nonnegative().optional(),
  salary_max: z.number().nonnegative().optional(),
  employment_type: z.string().max(50).optional(),
  description: z.string().min(10),
  source_url: z.string().url()
});

export const evidenceSchema = z.object({
  job_id: z.string().uuid(),
  employer_id: z.string().uuid().optional(),
  evidence_type: z.string().min(2),
  evidence_text: z.string().min(2),
  source_url: z.string().url().optional(),
  source_date: z.string().datetime().optional(),
  reliability_weight: z.number().min(0).max(1)
});