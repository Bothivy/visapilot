# VisaPilot — Production Backend Foundation

This is the next engineering layer after the clickable MVP.

## Included

- Next.js API foundation
- Supabase server/admin clients
- PostgreSQL schema + RLS policies
- Employer/job/evidence/score/application tables
- Job search API
- Job detail API
- Evidence ingestion + scoring API
- AI Copilot API
- Zod request validation
- Sponsorship verification engine
- Architecture documentation

## Setup

1. Create a Supabase project.
2. Run `supabase/migrations/001_initial.sql` in the Supabase SQL editor.
3. Copy `.env.example` to `.env.local`.
4. Add Supabase URL, anon key and service-role key.
5. Add OpenAI API key.
6. Run `npm install`.
7. Run `npm run dev`.

## API

GET `/api/jobs?q=care&location=scotland&min_score=70`

GET `/api/jobs/:id`

POST `/api/jobs`

POST `/api/evidence`

POST `/api/copilot`

## Important

Do not put `SUPABASE_SERVICE_ROLE_KEY` or `OPENAI_API_KEY` in client-side code.

This backend intentionally does NOT treat a sponsor licence as proof that a specific job offers sponsorship.

Before launch, add:
- authentication UI
- admin authentication/roles
- rate limiting
- audit logs
- job ingestion workers
- source freshness/expiry jobs
- automated tests
- monitoring
- payment integration
- legal/privacy documentation
