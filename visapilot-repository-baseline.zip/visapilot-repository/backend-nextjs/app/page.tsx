import { createClient } from "@/lib/supabase/server";

export default async function Home() {
  const supabase = await createClient();
  const { data } = await supabase
    .from("jobs")
    .select("id,title,location,salary_min,salary_max,status,last_verified_at")
    .eq("status", "active")
    .order("last_verified_at", { ascending: false })
    .limit(10);

  return (
    <main style={{padding: 40, fontFamily: "Inter, sans-serif"}}>
      <h1>VisaPilot API is running</h1>
      <p>UK sponsorship intelligence backend foundation.</p>
      <pre>{JSON.stringify(data ?? [], null, 2)}</pre>
    </main>
  );
}