import { NextRequest, NextResponse } from "next/server";
import { openai, OPENAI_MODEL } from "@/lib/openai";
import { createAdminClient } from "@/lib/supabase/admin";

export async function POST(request: NextRequest) {
  const { message, user_profile } = await request.json();

  if (!message || typeof message !== "string") {
    return NextResponse.json({ error: "message is required" }, { status: 400 });
  }

  const supabase = createAdminClient();
  const { data: jobs } = await supabase
    .from("job_search")
    .select("id,title,employer_name,location,salary_min,salary_max,sponsorship_score,confidence_level,last_verified_at")
    .eq("status", "active")
    .order("sponsorship_score", { ascending: false })
    .limit(20);

  const response = await openai.responses.create({
    model: OPENAI_MODEL,
    instructions: `You are VisaPilot Copilot, an AI assistant for people seeking UK jobs that may offer visa sponsorship.
Never state that a sponsor licence guarantees sponsorship of a specific role.
Distinguish eligibility, employer sponsorship history, and vacancy-specific evidence.
Do not give definitive immigration legal advice. Encourage official verification for important visa decisions.
Use the supplied job data when making recommendations and explain the evidence.`,
    input: JSON.stringify({
      user_message: message,
      user_profile: user_profile ?? {},
      available_jobs: jobs ?? []
    })
  });

  return NextResponse.json({ answer: response.output_text });
}