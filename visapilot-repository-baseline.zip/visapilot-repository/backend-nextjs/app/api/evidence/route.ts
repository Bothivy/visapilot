import { NextRequest, NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { evidenceSchema } from "@/lib/validation";
import { calculateSponsorshipScore } from "@/lib/verification";

export async function POST(request: NextRequest) {
  const body = await request.json();
  const parsed = evidenceSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const supabase = createAdminClient();

  const { data: evidence, error: evidenceError } = await supabase
    .from("sponsorship_evidence")
    .insert(parsed.data)
    .select()
    .single();

  if (evidenceError) return NextResponse.json({ error: evidenceError.message }, { status: 500 });

  const { data: allEvidence } = await supabase
    .from("sponsorship_evidence")
    .select("*")
    .eq("job_id", parsed.data.job_id);

  const result = calculateSponsorshipScore(allEvidence ?? []);

  const { data: score, error: scoreError } = await supabase
    .from("sponsorship_scores")
    .insert({
      job_id: parsed.data.job_id,
      score: result.score,
      confidence_level: result.confidence_level,
      score_breakdown: result.breakdown,
      explanation: result.explanation
    })
    .select()
    .single();

  if (scoreError) return NextResponse.json({ error: scoreError.message }, { status: 500 });

  return NextResponse.json({ evidence, score }, { status: 201 });
}