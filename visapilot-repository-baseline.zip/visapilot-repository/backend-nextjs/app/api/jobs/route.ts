import { NextRequest, NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { jobCreateSchema } from "@/lib/validation";

export async function GET(request: NextRequest) {
  const supabase = createAdminClient();
  const q = request.nextUrl.searchParams.get("q")?.trim();
  const location = request.nextUrl.searchParams.get("location")?.trim();
  const minScore = Number(request.nextUrl.searchParams.get("min_score") || 0);

  let query = supabase
    .from("job_search")
    .select("*")
    .eq("status", "active")
    .gte("sponsorship_score", minScore)
    .order("sponsorship_score", { ascending: false });

  if (q) query = query.or(`title.ilike.%${q}%,occupation.ilike.%${q}%,employer_name.ilike.%${q}%`);
  if (location) query = query.ilike("location", `%${location}%`);

  const { data, error } = await query.limit(50);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ jobs: data ?? [] });
}

export async function POST(request: NextRequest) {
  const body = await request.json();
  const parsed = jobCreateSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });

  const supabase = createAdminClient();
  const { data, error } = await supabase.from("jobs").insert(parsed.data).select().single();

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ job: data }, { status: 201 });
}