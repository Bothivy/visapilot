import "./globals.css";

export const metadata = {
  title: "VisaPilot",
  description: "UK visa sponsorship intelligence platform"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}