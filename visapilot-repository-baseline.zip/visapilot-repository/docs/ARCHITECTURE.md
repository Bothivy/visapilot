# VisaPilot Architecture

## Discovery

Source connectors -> normalisation -> canonical `jobs` row -> deduplication -> source authority/freshness.

Adzuna is already operational. The next implementation phase expands discovery across reliable first-party and broad sources rather than relying on a single aggregator.

## Sponsorship verification

Canonical job -> employer identity resolution -> Home Office sponsor register -> occupation/SOC rules -> salary evidence -> vacancy wording -> historical evidence -> sponsorship evidence band.

Exact sponsor-register matches can be automatically verified. Strong non-exact matches remain reviewable; fuzzy similarity alone must never assert legal identity.

## Candidate application flow

Profile/CV -> vacancy saved -> readiness checklist -> application analysis -> tailored CV -> cover letter -> answers -> final review -> external application -> delivery/follow-up -> interview -> offer.
