# Repository Baseline

This repository was reconstructed from the working VisaPilot artifacts generated during development through August 2026.

Baseline frontend builds:
- Candidate: Candidate V12 guided-flow fix.
- Developer: V30 automatic sponsorship verification.

Supabase remains the running data/backend environment. Existing production tables and data are not recreated or overwritten merely by cloning this repository. Migrations should be reviewed against the live database before applying to a new environment.

The repository is now intended to become the source of truth for future VisaPilot code changes.
