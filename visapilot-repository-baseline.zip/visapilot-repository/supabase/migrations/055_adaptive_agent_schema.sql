-- VisaPilot V55 — Adaptive Opportunity Agent

alter table public.opportunity_agent_recommendations
  add column if not exists base_priority_score integer,
  add column if not exists learning_adjustment integer not null default 0,
  add column if not exists used_adaptive_score boolean not null default false,
  add column if not exists adaptive_reason text;

select 'VisaPilot V55 adaptive opportunity agent fields ready' as status;
