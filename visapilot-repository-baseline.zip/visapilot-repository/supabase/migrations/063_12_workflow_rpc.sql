-- VisaPilot V63.12 — Workflow Integrity Persistence RPC
-- Uses the existing V57 application_workflow_state schema.
-- Run once in Supabase SQL Editor.

create or replace function public.persist_application_workflow_state(p_rows jsonb)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  r jsonb;
  v_count integer := 0;
  v_user_id uuid;
  v_job_id uuid;
  v_saved_job_id uuid;
  v_step text;
  v_reason text;
  v_version integer;
begin
  if auth.uid() is null then
    raise exception 'Authentication required';
  end if;

  if p_rows is null or jsonb_typeof(p_rows) <> 'array' then
    raise exception 'p_rows must be a JSON array';
  end if;

  for r in select * from jsonb_array_elements(p_rows)
  loop
    v_user_id := nullif(r->>'user_id','')::uuid;
    v_job_id := nullif(r->>'job_id','')::uuid;
    v_saved_job_id := nullif(r->>'saved_job_id','')::uuid;
    v_step := nullif(r->>'current_step','');
    v_reason := nullif(r->>'step_reason','');
    v_version := greatest(1,coalesce((r->>'workflow_version')::integer,1));

    if v_user_id is distinct from auth.uid() then
      continue;
    end if;

    if v_job_id is null or v_saved_job_id is null or v_step is null then
      continue;
    end if;

    -- Ensure this saved application genuinely belongs to the signed-in candidate.
    if not exists(
      select 1
      from public.saved_jobs s
      where s.id=v_saved_job_id
        and s.user_id=auth.uid()
        and s.job_id=v_job_id
    ) then
      continue;
    end if;

    insert into public.application_workflow_state (
      user_id,
      job_id,
      saved_job_id,
      current_step,
      step_reason,
      workflow_version,
      updated_at
    )
    values (
      v_user_id,
      v_job_id,
      v_saved_job_id,
      v_step,
      v_reason,
      v_version,
      now()
    )
    on conflict (user_id,saved_job_id) do update set
      job_id=excluded.job_id,
      current_step=excluded.current_step,
      step_reason=excluded.step_reason,
      workflow_version=excluded.workflow_version,
      updated_at=excluded.updated_at;

    v_count := v_count + 1;
  end loop;

  return jsonb_build_object('ok',true,'persisted',v_count);
end;
$$;

revoke all on function public.persist_application_workflow_state(jsonb) from public;
grant execute on function public.persist_application_workflow_state(jsonb) to authenticated;

select
  'VisaPilot workflow persistence RPC ready' as status,
  count(*) as current_rows
from public.application_workflow_state;
