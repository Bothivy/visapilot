-- VisaPilot — Fix save_live_job_rpc to match the real public.jobs schema
-- Run this once in Supabase SQL Editor.
-- This REPLACES the existing save_live_job_rpc function.
-- No table changes are made.

create or replace function public.save_live_job_rpc(p_job jsonb)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();

  v_job_id uuid;
  v_employer_id uuid;

  v_title text;
  v_company text;
  v_location text;
  v_description text;

  v_external_id text;
  v_source_url text;
  v_application_url text;
  v_dedupe_key text;

  v_salary_min numeric;
  v_salary_max numeric;
  v_salary_text text;

  v_published_at timestamptz;
  v_already_saved boolean := false;
begin
  if v_user is null then
    raise exception 'Authentication required';
  end if;

  v_title := btrim(coalesce(p_job->>'title',''));
  if v_title = '' then
    raise exception 'Invalid live job: title is missing';
  end if;

  v_company := btrim(
    coalesce(
      nullif(p_job->>'company',''),
      nullif(p_job#>>'{employers,name}',''),
      ''
    )
  );

  v_location := coalesce(nullif(p_job->>'location',''),'UK');
  v_description := coalesce(p_job->>'description','');

  v_external_id := nullif(
    coalesce(
      p_job->>'external_id',
      p_job->>'id'
    ),
    ''
  );

  v_source_url := nullif(
    coalesce(
      p_job->>'source_url',
      p_job->>'application_url'
    ),
    ''
  );

  v_application_url := nullif(
    coalesce(
      p_job->>'application_url',
      p_job->>'source_url'
    ),
    ''
  );

  -- Deterministic dedupe key for Adzuna imports.
  v_dedupe_key :=
    case
      when v_external_id is not null
        then 'adzuna:' || v_external_id
      when v_source_url is not null
        then 'adzuna:url:' || md5(v_source_url)
      else
        'adzuna:fallback:' || md5(lower(v_title || '|' || v_company || '|' || v_location))
    end;

  begin
    v_salary_min := nullif(p_job->>'salary_min','')::numeric;
  exception when others then
    v_salary_min := null;
  end;

  begin
    v_salary_max := nullif(p_job->>'salary_max','')::numeric;
  exception when others then
    v_salary_max := null;
  end;

  v_salary_text := nullif(p_job->>'salary_text','');

  begin
    v_published_at := nullif(p_job->>'created','')::timestamptz;
  exception when others then
    v_published_at := null;
  end;

  ---------------------------------------------------------------------------
  -- Employer resolution
  ---------------------------------------------------------------------------
  if v_company <> '' then
    select id
      into v_employer_id
    from public.employers
    where lower(name)=lower(v_company)
    order by id
    limit 1;

    if v_employer_id is null then
      begin
        insert into public.employers(name)
        values(v_company)
        returning id into v_employer_id;
      exception
        when unique_violation then
          select id
            into v_employer_id
          from public.employers
          where lower(name)=lower(v_company)
          order by id
          limit 1;
      end;
    end if;
  end if;

  ---------------------------------------------------------------------------
  -- Reuse an imported live job when we already know it.
  ---------------------------------------------------------------------------
  select id
    into v_job_id
  from public.jobs
  where
       dedupe_key = v_dedupe_key
    or (
         v_external_id is not null
         and (
              external_job_id = v_external_id
              or source_job_id = v_external_id
         )
       )
    or (
         v_source_url is not null
         and (
              source_url = v_source_url
              or application_url = v_source_url
         )
       )
  order by updated_at desc nulls last, created_at desc nulls last
  limit 1;

  ---------------------------------------------------------------------------
  -- Import the live vacancy using ONLY columns that exist in your jobs table.
  ---------------------------------------------------------------------------
  if v_job_id is null then
    insert into public.jobs (
      employer_id,
      title,
      location,

      salary_min,
      salary_max,
      salary_text,
      currency,

      description,

      source_name,
      source_key,
      source_job_id,
      source_url,

      application_url,
      application_method,

      status,
      dedupe_key,
      raw_metadata,

      published_at,
      last_seen_at,
      created_at,
      updated_at,

      discovery_source,
      external_job_id,
      discovered_at,
      source_payload
    )
    values (
      v_employer_id,
      v_title,
      v_location,

      v_salary_min,
      v_salary_max,
      v_salary_text,
      'GBP',

      v_description,

      'Adzuna',
      'adzuna',
      v_external_id,
      v_source_url,

      v_application_url,
      'external',

      'active',
      v_dedupe_key,
      coalesce(p_job,'{}'::jsonb),

      v_published_at,
      now(),
      now(),
      now(),

      'candidate_live_search',
      v_external_id,
      now(),
      coalesce(p_job,'{}'::jsonb)
    )
    returning id into v_job_id;

  else
    -- Refresh the live record without destroying existing intelligence.
    update public.jobs
    set
      employer_id = coalesce(employer_id,v_employer_id),
      title = v_title,
      location = v_location,

      salary_min = coalesce(v_salary_min,salary_min),
      salary_max = coalesce(v_salary_max,salary_max),
      salary_text = coalesce(v_salary_text,salary_text),

      description = case
        when v_description <> '' then v_description
        else description
      end,

      source_name = coalesce(source_name,'Adzuna'),
      source_key = coalesce(source_key,'adzuna'),
      source_job_id = coalesce(source_job_id,v_external_id),
      source_url = coalesce(v_source_url,source_url),

      application_url = coalesce(v_application_url,application_url),
      application_method = coalesce(application_method,'external'),

      status = 'active',
      dedupe_key = coalesce(dedupe_key,v_dedupe_key),

      published_at = coalesce(v_published_at,published_at),
      last_seen_at = now(),
      updated_at = now(),

      discovery_source = coalesce(discovery_source,'candidate_live_search'),
      external_job_id = coalesce(external_job_id,v_external_id),
      discovered_at = coalesce(discovered_at,now()),
      source_payload = coalesce(p_job,source_payload)
    where id = v_job_id;
  end if;

  ---------------------------------------------------------------------------
  -- Add to this candidate's Applications.
  ---------------------------------------------------------------------------
  if exists (
    select 1
    from public.saved_jobs
    where user_id = v_user
      and job_id = v_job_id
  ) then
    v_already_saved := true;
  else
    insert into public.saved_jobs (
      user_id,
      job_id,
      status
    )
    values (
      v_user,
      v_job_id,
      'Saved'
    );
  end if;

  return jsonb_build_object(
    'ok', true,
    'job_id', v_job_id,
    'already_saved', v_already_saved
  );
end;
$$;

revoke all on function public.save_live_job_rpc(jsonb) from public;
grant execute on function public.save_live_job_rpc(jsonb) to authenticated;

select
  'VisaPilot save_live_job_rpc updated to match the real jobs schema' as status;
