-- VisaPilot V51 — Application Intelligence & Conversion

create table if not exists public.application_intelligence (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 saved_job_id uuid not null references public.saved_jobs(id) on delete cascade,
 job_id uuid not null references public.jobs(id) on delete cascade,
 readiness_score integer not null check(readiness_score between 0 and 100),
 candidate_fit integer not null default 0,
 cv_evidence_score integer not null default 0,
 sponsorship_score integer not null default 0,
 application_pack_score integer not null default 0,
 decision text not null check(decision in ('apply_now','improve_first','lower_priority')),
 strengths jsonb not null default '[]'::jsonb,
 gaps jsonb not null default '[]'::jsonb,
 summary text,
 scored_at timestamptz not null default now(),
 unique(user_id,saved_job_id)
);

create index if not exists idx_application_intel_user
on public.application_intelligence(user_id,readiness_score desc);

alter table public.application_intelligence enable row level security;

drop policy if exists "users read own application intelligence" on public.application_intelligence;
create policy "users read own application intelligence"
on public.application_intelligence for select to authenticated
using(auth.uid()=user_id);

grant select on public.application_intelligence to authenticated;
