-- VisaPilot V53 — Outcome Learning & Conversion Analytics

create table if not exists public.application_conversion_summary (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade unique,
 total_applications integer not null default 0,
 applied_count integer not null default 0,
 interview_count integer not null default 0,
 offer_count integer not null default 0,
 rejected_count integer not null default 0,
 response_count integer not null default 0,
 interview_rate numeric not null default 0,
 offer_rate numeric not null default 0,
 response_rate numeric not null default 0,
 updated_at timestamptz not null default now()
);

create table if not exists public.outcome_learning_insights (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 insight_type text not null,
 insight_key text not null,
 label text not null,
 sample_size integer not null default 0,
 positive_outcomes integer not null default 0,
 negative_outcomes integer not null default 0,
 conversion_rate numeric not null default 0,
 baseline_rate numeric not null default 0,
 impact_score numeric not null default 0,
 explanation text,
 updated_at timestamptz not null default now(),
 unique(user_id,insight_type,insight_key)
);

alter table public.application_conversion_summary enable row level security;
alter table public.outcome_learning_insights enable row level security;

drop policy if exists "users read own conversion summary" on public.application_conversion_summary;
create policy "users read own conversion summary"
on public.application_conversion_summary for select to authenticated
using(auth.uid()=user_id);

drop policy if exists "users read own outcome insights" on public.outcome_learning_insights;
create policy "users read own outcome insights"
on public.outcome_learning_insights for select to authenticated
using(auth.uid()=user_id);

grant select on public.application_conversion_summary, public.outcome_learning_insights to authenticated;
