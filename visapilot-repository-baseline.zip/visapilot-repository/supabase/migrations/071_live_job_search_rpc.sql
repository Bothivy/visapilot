-- VisaPilot Candidate V5 — Live Internet Search via Supabase REST/RPC
-- Run once after storing the Adzuna credentials in Vault.

create extension if not exists http with schema extensions;

create or replace function public.search_live_jobs_rpc(
  p_query text,
  p_location text default '',
  p_limit integer default 30
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_app_id text;
  v_app_key text;
  v_status integer;
  v_content varchar;
  v_payload jsonb;
  v_jobs jsonb;
  v_limit integer;
begin
  if auth.uid() is null then
    raise exception 'Authentication required';
  end if;

  p_query := btrim(coalesce(p_query,''));
  p_location := btrim(coalesce(p_location,''));

  if p_query = '' then
    raise exception 'Search query is required';
  end if;

  v_limit := greatest(1, least(coalesce(p_limit,30), 50));

  select decrypted_secret into v_app_id
  from vault.decrypted_secrets
  where name='adzuna_app_id'
  limit 1;

  select decrypted_secret into v_app_key
  from vault.decrypted_secrets
  where name='adzuna_app_key'
  limit 1;

  if nullif(v_app_id,'') is null or nullif(v_app_key,'') is null
     or v_app_id='YOUR_ADZUNA_APP_ID'
     or v_app_key='YOUR_ADZUNA_APP_KEY' then
    raise exception 'Live job search credentials are not configured';
  end if;

  -- Supabase's http extension performs the external request from Postgres,
  -- so API credentials never reach the candidate browser.
  select h.status, h.content
    into v_status, v_content
  from extensions.http_get(
    'https://api.adzuna.com/v1/api/jobs/gb/search/1'::varchar,
    jsonb_strip_nulls(jsonb_build_object(
      'app_id', v_app_id,
      'app_key', v_app_key,
      'results_per_page', v_limit,
      'what', p_query,
      'where', nullif(p_location,''),
      'sort_by', 'date',
      'content-type', 'application/json'
    ))
  ) h;

  if v_status <> 200 then
    raise exception 'Live vacancy provider returned HTTP %', v_status;
  end if;

  v_payload := v_content::jsonb;

  select coalesce(jsonb_agg(
    jsonb_build_object(
      'external_id', coalesce(x->>'id',''),
      'title', coalesce(x->>'title',''),
      'company', coalesce(x#>>'{company,display_name}',''),
      'employers', jsonb_build_object('name',coalesce(x#>>'{company,display_name}','')),
      'location', coalesce(x#>>'{location,display_name}',p_location,'UK'),
      'description', coalesce(x->>'description',''),
      'salary_min', nullif(x->>'salary_min','')::numeric,
      'salary_max', nullif(x->>'salary_max','')::numeric,
      'salary_text',
        case
          when x ? 'salary_min' or x ? 'salary_max'
          then concat(
            '£',
            to_char(coalesce(nullif(x->>'salary_min','')::numeric,nullif(x->>'salary_max','')::numeric),'FM999,999,990'),
            case
              when x ? 'salary_min' and x ? 'salary_max'
              then concat(' – £',to_char(nullif(x->>'salary_max','')::numeric,'FM999,999,990'))
              else ''
            end
          )
          else ''
        end,
      'created', x->>'created',
      'application_url', x->>'redirect_url',
      'source_url', x->>'redirect_url',
      'source', 'adzuna'
    )
  ), '[]'::jsonb)
  into v_jobs
  from jsonb_array_elements(coalesce(v_payload->'results','[]'::jsonb)) x;

  return jsonb_build_object(
    'jobs', v_jobs,
    'count', coalesce((v_payload->>'count')::integer, jsonb_array_length(v_jobs))
  );
end;
$$;

revoke all on function public.search_live_jobs_rpc(text,text,integer) from public;
grant execute on function public.search_live_jobs_rpc(text,text,integer) to authenticated;


create or replace function public.save_live_job_rpc(p_job jsonb)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_job_id uuid;
  v_employer_id uuid;
  v_company text := btrim(coalesce(p_job->>'company',p_job#>>'{employers,name}',''));
  v_url text := coalesce(nullif(p_job->>'application_url',''),nullif(p_job->>'source_url',''));
  v_created timestamptz;
  v_already_saved boolean := false;
begin
  if v_user is null then
    raise exception 'Authentication required';
  end if;

  if btrim(coalesce(p_job->>'title','')) = '' then
    raise exception 'Invalid live job';
  end if;

  begin
    v_created := nullif(p_job->>'created','')::timestamptz;
  exception when others then
    v_created := now();
  end;

  if v_company <> '' then
    select id into v_employer_id
    from public.employers
    where lower(name)=lower(v_company)
    order by id
    limit 1;

    if v_employer_id is null then
      begin
        insert into public.employers(name)
        values(v_company)
        returning id into v_employer_id;
      exception when unique_violation then
        select id into v_employer_id
        from public.employers
        where lower(name)=lower(v_company)
        limit 1;
      end;
    end if;
  end if;

  if v_url is not null then
    select id into v_job_id
    from public.jobs
    where source_url=v_url or application_url=v_url
    order by created_at desc
    limit 1;
  end if;

  if v_job_id is null then
    insert into public.jobs(
      employer_id,
      title,
      location,
      description,
      application_url,
      source_url,
      status,
      posted_at,
      discovered_at,
      last_seen_at,
      created_at,
      updated_at
    )
    values(
      v_employer_id,
      p_job->>'title',
      coalesce(nullif(p_job->>'location',''),'UK'),
      coalesce(p_job->>'description',''),
      v_url,
      v_url,
      'active',
      coalesce(v_created,now()),
      now(),
      now(),
      now(),
      now()
    )
    returning id into v_job_id;
  else
    update public.jobs
    set
      employer_id=coalesce(employer_id,v_employer_id),
      last_seen_at=now(),
      updated_at=now(),
      status='active'
    where id=v_job_id;
  end if;

  if exists(
    select 1 from public.saved_jobs
    where user_id=v_user and job_id=v_job_id
  ) then
    v_already_saved := true;
  else
    insert into public.saved_jobs(user_id,job_id,status)
    values(v_user,v_job_id,'Saved');
  end if;

  return jsonb_build_object(
    'ok',true,
    'job_id',v_job_id,
    'already_saved',v_already_saved
  );
end;
$$;

revoke all on function public.save_live_job_rpc(jsonb) from public;
grant execute on function public.save_live_job_rpc(jsonb) to authenticated;

select 'VisaPilot live job REST/RPC search ready' as status;
