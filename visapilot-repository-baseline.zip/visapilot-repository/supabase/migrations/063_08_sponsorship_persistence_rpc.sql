-- VisaPilot V63.8 — Sponsorship Intelligence REST RPC
-- This replaces the failing Edge Function path with a PostgREST RPC.
-- Run once in Supabase SQL Editor.

create or replace function public.persist_sponsorship_intelligence(p_rows jsonb)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  r jsonb;
  v_count integer := 0;
  v_job_id uuid;
  v_employer_id uuid;
  v_score integer;
  v_confidence text;
begin
  if auth.uid() is null then
    raise exception 'Authentication required';
  end if;

  if p_rows is null or jsonb_typeof(p_rows) <> 'array' then
    raise exception 'p_rows must be a JSON array';
  end if;

  for r in select * from jsonb_array_elements(p_rows)
  loop
    v_job_id := nullif(r->>'job_id','')::uuid;
    v_employer_id := nullif(r->>'employer_id','')::uuid;
    v_score := greatest(0, least(100, coalesce((r->>'score')::integer,0)));
    v_confidence := lower(coalesce(r->>'confidence','low'));

    if v_job_id is null then
      continue;
    end if;

    if v_confidence not in ('low','medium','high') then
      v_confidence := 'low';
    end if;

    -- Only persist against an existing job.
    if not exists(select 1 from public.jobs j where j.id = v_job_id) then
      continue;
    end if;

    insert into public.job_sponsorship_intelligence (
      job_id,
      employer_id,
      score,
      confidence,
      positive_signals,
      negative_signals,
      evidence,
      summary,
      scored_at,
      updated_at
    )
    values (
      v_job_id,
      v_employer_id,
      v_score,
      v_confidence,
      coalesce(r->'positive_signals','[]'::jsonb),
      coalesce(r->'negative_signals','[]'::jsonb),
      coalesce(r->'evidence','{}'::jsonb),
      nullif(r->>'summary',''),
      now(),
      now()
    )
    on conflict (job_id) do update set
      employer_id = excluded.employer_id,
      score = excluded.score,
      confidence = excluded.confidence,
      positive_signals = excluded.positive_signals,
      negative_signals = excluded.negative_signals,
      evidence = excluded.evidence,
      summary = excluded.summary,
      scored_at = excluded.scored_at,
      updated_at = excluded.updated_at;

    v_count := v_count + 1;
  end loop;

  return jsonb_build_object('ok',true,'persisted',v_count);
end;
$$;

revoke all on function public.persist_sponsorship_intelligence(jsonb) from public;
grant execute on function public.persist_sponsorship_intelligence(jsonb) to authenticated;
