create table if not exists public.opportunity_agent_preferences (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade unique,
 enabled boolean not null default true,
 minimum_priority_score integer not null default 60 check(minimum_priority_score between 0 and 100),
 max_jobs_per_alert integer not null default 5 check(max_jobs_per_alert between 1 and 10),
 last_run_at timestamptz,last_email_at timestamptz,
 created_at timestamptz not null default now(),updated_at timestamptz not null default now()
);
create table if not exists public.opportunity_agent_recommendations (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 job_id uuid not null references public.jobs(id) on delete cascade,
 priority_score integer not null check(priority_score between 0 and 100),
 candidate_fit integer not null default 0,
 sponsorship_score integer not null default 0,
 reason_summary text,created_at timestamptz not null default now(),
 emailed_at timestamptz,dismissed_at timestamptz,
 unique(user_id,job_id)
);
alter table public.opportunity_agent_preferences enable row level security;
alter table public.opportunity_agent_recommendations enable row level security;
drop policy if exists "users manage own agent prefs" on public.opportunity_agent_preferences;
create policy "users manage own agent prefs" on public.opportunity_agent_preferences for all to authenticated using(auth.uid()=user_id) with check(auth.uid()=user_id);
drop policy if exists "users read own agent recs" on public.opportunity_agent_recommendations;
create policy "users read own agent recs" on public.opportunity_agent_recommendations for select to authenticated using(auth.uid()=user_id);
drop policy if exists "users update own agent recs" on public.opportunity_agent_recommendations;
create policy "users update own agent recs" on public.opportunity_agent_recommendations for update to authenticated using(auth.uid()=user_id) with check(auth.uid()=user_id);
grant select,insert,update on public.opportunity_agent_preferences to authenticated;
grant select,update on public.opportunity_agent_recommendations to authenticated;
