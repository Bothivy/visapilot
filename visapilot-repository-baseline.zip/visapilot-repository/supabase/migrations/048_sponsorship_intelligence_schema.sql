create table if not exists public.job_sponsorship_intelligence (
 id uuid primary key default gen_random_uuid(),
 job_id uuid not null references public.jobs(id) on delete cascade unique,
 employer_id uuid references public.employers(id) on delete cascade,
 score integer not null check(score between 0 and 100),
 confidence text not null check(confidence in ('low','medium','high')),
 positive_signals jsonb not null default '[]'::jsonb,
 negative_signals jsonb not null default '[]'::jsonb,
 evidence jsonb not null default '{}'::jsonb,
 summary text,
 scored_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
alter table public.job_sponsorship_intelligence enable row level security;
drop policy if exists "authenticated read sponsorship intelligence" on public.job_sponsorship_intelligence;
create policy "authenticated read sponsorship intelligence" on public.job_sponsorship_intelligence for select to authenticated using(true);
grant select on public.job_sponsorship_intelligence to authenticated;
