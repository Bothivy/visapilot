-- VisaPilot V63.10 — Adaptive Scoring Persistence RPC
-- Uses the existing V54 adaptive_job_priority schema.
-- Run once in Supabase SQL Editor.

create or replace function public.persist_adaptive_job_priority(p_rows jsonb)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  r jsonb;
  v_count integer := 0;
  v_user_id uuid;
  v_job_id uuid;
  v_base integer;
  v_adjustment integer;
  v_adaptive integer;
  v_reason text;
begin
  if auth.uid() is null then
    raise exception 'Authentication required';
  end if;

  if p_rows is null or jsonb_typeof(p_rows) <> 'array' then
    raise exception 'p_rows must be a JSON array';
  end if;

  for r in select * from jsonb_array_elements(p_rows)
  loop
    v_user_id := nullif(r->>'user_id','')::uuid;
    v_job_id := nullif(r->>'job_id','')::uuid;
    v_base := greatest(0, least(100, coalesce((r->>'base_priority_score')::integer,0)));
    v_adjustment := greatest(-20, least(20, coalesce((r->>'learning_adjustment')::integer,0)));
    v_adaptive := greatest(0, least(100, coalesce((r->>'adaptive_score')::integer,v_base+v_adjustment)));
    v_reason := nullif(r->>'learning_reason','');

    -- A signed-in candidate may only persist their own adaptive scores.
    if v_user_id is distinct from auth.uid() then
      continue;
    end if;

    if v_job_id is null then
      continue;
    end if;

    if not exists(select 1 from public.jobs j where j.id=v_job_id) then
      continue;
    end if;

    insert into public.adaptive_job_priority (
      user_id,
      job_id,
      base_priority_score,
      learning_adjustment,
      adaptive_score,
      learning_reason,
      updated_at
    )
    values (
      v_user_id,
      v_job_id,
      v_base,
      v_adjustment,
      v_adaptive,
      coalesce(v_reason,'No strong learned conversion pattern changed this job''s ranking.'),
      now()
    )
    on conflict (user_id,job_id) do update set
      base_priority_score=excluded.base_priority_score,
      learning_adjustment=excluded.learning_adjustment,
      adaptive_score=excluded.adaptive_score,
      learning_reason=excluded.learning_reason,
      updated_at=excluded.updated_at;

    v_count := v_count + 1;
  end loop;

  return jsonb_build_object('ok',true,'persisted',v_count);
end;
$$;

revoke all on function public.persist_adaptive_job_priority(jsonb) from public;
grant execute on function public.persist_adaptive_job_priority(jsonb) to authenticated;

select
  'VisaPilot adaptive scoring RPC ready' as status,
  count(*) as current_rows
from public.adaptive_job_priority;
