-- VisaPilot V56 — Application Action Queue
create table if not exists public.application_action_queue (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 job_id uuid not null references public.jobs(id) on delete cascade,
 saved_job_id uuid references public.saved_jobs(id) on delete cascade,
 queue_rank integer not null,
 urgency_score integer not null default 0 check(urgency_score between 0 and 100),
 action_type text not null,
 action_label text not null,
 action_reason text,
 source_score integer not null default 0,
 created_at timestamptz not null default now(),
 completed_at timestamptz,
 unique(user_id,job_id,action_type)
);
alter table public.application_action_queue enable row level security;
drop policy if exists "users read own action queue" on public.application_action_queue;
create policy "users read own action queue" on public.application_action_queue for select to authenticated using(auth.uid()=user_id);
drop policy if exists "users update own action queue" on public.application_action_queue;
create policy "users update own action queue" on public.application_action_queue for update to authenticated using(auth.uid()=user_id) with check(auth.uid()=user_id);
grant select,update on public.application_action_queue to authenticated;
