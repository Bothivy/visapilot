create extension if not exists pg_trgm;

create or replace function public.normalise_employer_name(input_name text)
returns text language sql immutable as $$
select trim(regexp_replace(regexp_replace(regexp_replace(lower(coalesce(input_name,'')),'&',' and ','g'),'[^a-z0-9]+',' ','g'),'\s+',' ','g'));
$$;

alter table public.sponsor_register
add column if not exists organisation_name_normalised text
generated always as (public.normalise_employer_name(organisation_name)) stored;

create index if not exists sponsor_register_name_trgm_idx
on public.sponsor_register using gin (organisation_name_normalised gin_trgm_ops);

create index if not exists sponsor_register_route_idx on public.sponsor_register(route);
create index if not exists sponsor_register_town_idx on public.sponsor_register(town_city);

create or replace function public.match_sponsor_employer(
 p_employer_name text,
 p_location text default null,
 p_limit integer default 5
)
returns table(
 organisation_name text,
 town_city text,
 county text,
 type_rating text,
 route text,
 name_similarity numeric,
 match_status text
)
language sql stable as $$
with candidate as (
 select sr.organisation_name,sr.town_city,sr.county,sr.type_rating,sr.route,
 similarity(public.normalise_employer_name(p_employer_name),sr.organisation_name_normalised)::numeric similarity_score
 from public.sponsor_register sr
 where lower(coalesce(sr.route,'')) like '%skilled worker%'
 and (sr.organisation_name_normalised=public.normalise_employer_name(p_employer_name)
      or similarity(public.normalise_employer_name(p_employer_name),sr.organisation_name_normalised)>=0.70)
)
select c.organisation_name,c.town_city,c.county,c.type_rating,c.route,round(c.similarity_score,3),
 case
  when public.normalise_employer_name(c.organisation_name)=public.normalise_employer_name(p_employer_name) then 'verified_exact'
  when c.similarity_score>=0.92 then 'strong_match'
  when c.similarity_score>=0.85 then 'possible_match'
  else 'manual_review'
 end
from candidate c
order by case when public.normalise_employer_name(c.organisation_name)=public.normalise_employer_name(p_employer_name) then 0 else 1 end,
 c.similarity_score desc,c.organisation_name
limit greatest(p_limit,1);
$$;
