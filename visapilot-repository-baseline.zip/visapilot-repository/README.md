# VisaPilot

VisaPilot is a sponsorship-focused UK job discovery and application intelligence product.

## Current product architecture

- `candidate-app/` — latest candidate-facing browser application (guided journey through Offer).
- `developer-console/` — developer sponsorship verification console.
- `supabase/migrations/` — database schema, RPC and verification migrations recovered from the working Supabase implementation.
- `backend-nextjs/` — earlier structured Next.js backend implementation retained as reference for migration from single-file HTML prototypes.
- `data/reference/` — public reference-data templates and current sponsor-register snapshot. No private candidate data belongs here.
- `docs/` — architecture and operational notes.

## Current candidate journey

Account → Profile + CV → live job search → sponsorship intelligence → save → guided application preparation → apply → track → interview → offer.

VisaPilot intentionally stops at **Offer**; post-offer intelligence is out of scope.

## Sponsorship intelligence principle

VisaPilot ranks the **strength of sponsorship evidence**. It does not claim that an employer will issue a Certificate of Sponsorship.

Evidence layers include:

1. Current Home Office sponsor-register verification.
2. Vacancy-level positive/negative sponsorship wording.
3. Occupation/SOC eligibility evidence.
4. Salary/going-rate evidence.
5. Employer-role sponsorship history.
6. Candidate-specific eligibility as a separate downstream layer.

## Security

Do not commit API keys, passwords, Supabase service-role keys, `.env` files, or private candidate data. Use Supabase Vault / deployment environment variables for secrets.

## Current development priority

V31: Multi-source live-job discovery and deduplication, with Adzuna as one connector rather than the sole job source. Planned source classes include NHS Jobs, Find a Job, direct employer/ATS feeds, councils/public bodies, universities and permitted public-sector connectors.
